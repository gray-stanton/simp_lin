#' My simple linear regression package
#' 
#' Description of your package
#' 
#' @docType package
#' @author Gray Stanton <gray@graystanton.com>
#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib simplin
#' @name simplin
NULL