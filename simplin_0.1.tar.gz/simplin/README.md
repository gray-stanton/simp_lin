# simp_lin
Simple Linear Regression R package, for Assignment 1 of STAT 600 (Computational Statistics), CSU.
